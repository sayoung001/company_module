"""
신분증 자동화 프로그램 v1.0
Phase 1: 엑셀 자동 복사 기능
"""

import customtkinter as ctk
from tkinter import filedialog, messagebox
import os
from datetime import datetime
from excel_handler import ExcelHandler

# 테마 설정
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


class IDAutomationApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        # 윈도우 설정
        self.title("신분증 자동화 프로그램 v1.0")
        self.geometry("800x600")
        self.minsize(700, 500)
        
        # 파일 경로 저장
        self.source_file = None  # 종합양식
        self.target_file = None  # 출석부양식
        self.scan_file = None    # 스캔 이미지
        
        # Excel 핸들러
        self.excel_handler = ExcelHandler()
        
        # UI 구성
        self.create_widgets()
        
    def create_widgets(self):
        # 메인 프레임
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # 제목
        title_label = ctk.CTkLabel(
            self.main_frame, 
            text="🪪 신분증 자동화 프로그램",
            font=ctk.CTkFont(size=24, weight="bold")
        )
        title_label.pack(pady=(0, 20))
        
        # 탭 뷰 생성
        self.tabview = ctk.CTkTabview(self.main_frame)
        self.tabview.pack(fill="both", expand=True)
        
        # 탭 추가
        self.tab_excel = self.tabview.add("1️⃣ 엑셀 복사")
        self.tab_masking = self.tabview.add("2️⃣ 마스킹")
        self.tab_split = self.tabview.add("3️⃣ 분리저장")
        self.tab_verify = self.tabview.add("4️⃣ 검증")
        
        # 각 탭 UI 구성
        self.setup_excel_tab()
        self.setup_masking_tab()
        self.setup_split_tab()
        self.setup_verify_tab()
        
        # 상태바
        self.status_var = ctk.StringVar(value="준비됨")
        self.status_bar = ctk.CTkLabel(
            self.main_frame,
            textvariable=self.status_var,
            font=ctk.CTkFont(size=12)
        )
        self.status_bar.pack(side="bottom", pady=(10, 0))
    
    # ==================== 1️⃣ 엑셀 복사 탭 ====================
    def setup_excel_tab(self):
        frame = ctk.CTkFrame(self.tab_excel, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # 설명
        desc = ctk.CTkLabel(
            frame,
            text="종합양식의 데이터를 출석부양식으로 자동 복사합니다.",
            font=ctk.CTkFont(size=14)
        )
        desc.pack(pady=(0, 20))
        
        # 종합양식 파일 선택
        source_frame = ctk.CTkFrame(frame)
        source_frame.pack(fill="x", pady=10)
        
        ctk.CTkLabel(source_frame, text="📁 종합양식:", width=100).pack(side="left", padx=5)
        self.source_entry = ctk.CTkEntry(source_frame, width=400, state="readonly")
        self.source_entry.pack(side="left", padx=5)
        ctk.CTkButton(
            source_frame, text="찾아보기", width=100,
            command=self.select_source_file
        ).pack(side="left", padx=5)
        
        # 출석부양식 파일 선택
        target_frame = ctk.CTkFrame(frame)
        target_frame.pack(fill="x", pady=10)
        
        ctk.CTkLabel(target_frame, text="📁 출석부양식:", width=100).pack(side="left", padx=5)
        self.target_entry = ctk.CTkEntry(target_frame, width=400, state="readonly")
        self.target_entry.pack(side="left", padx=5)
        ctk.CTkButton(
            target_frame, text="찾아보기", width=100,
            command=self.select_target_file
        ).pack(side="left", padx=5)
        
        # 미리보기 영역
        preview_label = ctk.CTkLabel(frame, text="📋 데이터 미리보기:", anchor="w")
        preview_label.pack(fill="x", pady=(20, 5))
        
        self.preview_text = ctk.CTkTextbox(frame, height=200)
        self.preview_text.pack(fill="both", expand=True)
        
        # 버튼 영역
        btn_frame = ctk.CTkFrame(frame, fg_color="transparent")
        btn_frame.pack(fill="x", pady=20)
        
        ctk.CTkButton(
            btn_frame, text="🔍 미리보기", width=150,
            command=self.preview_data
        ).pack(side="left", padx=10)
        
        ctk.CTkButton(
            btn_frame, text="📋 복사 실행", width=150,
            fg_color="green", hover_color="darkgreen",
            command=self.copy_excel_data
        ).pack(side="left", padx=10)
    
    def select_source_file(self):
        file_path = filedialog.askopenfilename(
            title="종합양식 파일 선택",
            filetypes=[("Excel files", "*.xlsx *.xls")]
        )
        if file_path:
            self.source_file = file_path
            self.source_entry.configure(state="normal")
            self.source_entry.delete(0, "end")
            self.source_entry.insert(0, os.path.basename(file_path))
            self.source_entry.configure(state="readonly")
            self.status_var.set(f"종합양식 선택됨: {os.path.basename(file_path)}")
    
    def select_target_file(self):
        file_path = filedialog.askopenfilename(
            title="출석부양식 파일 선택",
            filetypes=[("Excel files", "*.xlsx *.xls")]
        )
        if file_path:
            self.target_file = file_path
            self.target_entry.configure(state="normal")
            self.target_entry.delete(0, "end")
            self.target_entry.insert(0, os.path.basename(file_path))
            self.target_entry.configure(state="readonly")
            self.status_var.set(f"출석부양식 선택됨: {os.path.basename(file_path)}")
    
    def preview_data(self):
        if not self.source_file:
            messagebox.showwarning("경고", "종합양식 파일을 먼저 선택하세요.")
            return
        
        try:
            data = self.excel_handler.read_source_data(self.source_file)
            
            self.preview_text.delete("1.0", "end")
            self.preview_text.insert("1.0", f"총 {len(data)}명의 데이터\n")
            self.preview_text.insert("end", "=" * 60 + "\n")
            self.preview_text.insert("end", f"{'No.':<5} {'성명':<10} {'생년월일':<12} {'전화번호':<15} {'취약구분':<10}\n")
            self.preview_text.insert("end", "-" * 60 + "\n")
            
            for row in data:
                no = row.get('no', '')
                name = row.get('name', '')
                birth = row.get('birth', '')
                phone = row.get('phone', '')
                vulnerable = row.get('vulnerable', '')
                self.preview_text.insert("end", f"{no:<5} {name:<10} {birth:<12} {phone:<15} {vulnerable:<10}\n")
            
            self.status_var.set(f"미리보기 완료: {len(data)}명")
            
        except Exception as e:
            messagebox.showerror("오류", f"파일 읽기 오류: {str(e)}")
    
    def copy_excel_data(self):
        if not self.source_file:
            messagebox.showwarning("경고", "종합양식 파일을 먼저 선택하세요.")
            return
        if not self.target_file:
            messagebox.showwarning("경고", "출석부양식 파일을 먼저 선택하세요.")
            return
        
        try:
            result = self.excel_handler.copy_to_attendance(
                self.source_file, 
                self.target_file
            )
            
            if result['success']:
                messagebox.showinfo(
                    "완료", 
                    f"✅ 복사 완료!\n\n"
                    f"복사된 인원: {result['count']}명\n"
                    f"저장 위치: {result['saved_path']}"
                )
                self.status_var.set(f"복사 완료: {result['count']}명")
            else:
                messagebox.showerror("오류", result['message'])
                
        except Exception as e:
            messagebox.showerror("오류", f"복사 중 오류 발생: {str(e)}")
    
    # ==================== 2️⃣ 마스킹 탭 (추후 구현) ====================
    def setup_masking_tab(self):
        frame = ctk.CTkFrame(self.tab_masking, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        ctk.CTkLabel(
            frame,
            text="🚧 Phase 2에서 구현 예정",
            font=ctk.CTkFont(size=18)
        ).pack(expand=True)
        
        ctk.CTkLabel(
            frame,
            text="신분증 이미지의 주민번호 뒷자리, 주소 등을 자동 마스킹합니다.",
            font=ctk.CTkFont(size=14)
        ).pack()
    
    # ==================== 3️⃣ 분리저장 탭 (추후 구현) ====================
    def setup_split_tab(self):
        frame = ctk.CTkFrame(self.tab_split, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        ctk.CTkLabel(
            frame,
            text="🚧 Phase 3에서 구현 예정",
            font=ctk.CTkFont(size=18)
        ).pack(expand=True)
        
        ctk.CTkLabel(
            frame,
            text="스캔된 종합 이미지에서 개별 신분증을 분리하여 저장합니다.",
            font=ctk.CTkFont(size=14)
        ).pack()
    
    # ==================== 4️⃣ 검증 탭 (추후 구현) ====================
    def setup_verify_tab(self):
        frame = ctk.CTkFrame(self.tab_verify, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        ctk.CTkLabel(
            frame,
            text="🚧 Phase 4에서 구현 예정",
            font=ctk.CTkFont(size=18)
        ).pack(expand=True)
        
        ctk.CTkLabel(
            frame,
            text="OCR로 신분증을 읽어 엑셀 데이터와 비교 검증합니다.",
            font=ctk.CTkFont(size=14)
        ).pack()


if __name__ == "__main__":
    app = IDAutomationApp()
    app.mainloop()
